clc;
clear all;
close all;
[path1,~] = imgetfile();
%image
img1 = imresize(imread(path1),[300, 300]);
[path,~] = imgetfile();
%ref image
img2 = imresize(imread(path),[300 300]);

if(ndims(img1) ~= ndims(img2))
    if(ndims(img1) == 3)
        img1 = rgb2gray(img1);
    end
    if(ndims(img2) == 3)
        img2 = rgb2gray(img2);
    end
end

psnr_val = psnr(img1,img2)
ssim_val = ssim(img1,img2)